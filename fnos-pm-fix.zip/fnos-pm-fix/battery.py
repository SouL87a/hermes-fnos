import os, subprocess, sys
sys.path.insert(0, '/vol1/@appcenter/hermes/runtime/hermes')
from pathlib import Path
from hermes_cli._launchers import runtime_command
root = Path('/vol1/@appcenter/hermes/runtime/hermes')
cases = [['doctor'], ['security','audit'], ['prompt-size'], ['dump','--help'],
         ['gateway','status'], ['pm','status'], ['backup','--help'], ['update','--plan']]
for argv in cases:
    cmd = runtime_command(root, argv)
    r = subprocess.run(cmd, cwd=str(root), stdin=subprocess.DEVNULL,
                       capture_output=True, text=True, env=dict(os.environ))
    out = (r.stdout or '') + (r.stderr or '')
    broken = 'no dependency environment is committed' in out
    print(f'{" ".join(argv):18} exit={r.returncode:<3} broken={str(broken):5}')
