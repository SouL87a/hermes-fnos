# 打包改动：把「依赖环境登记」接进 fnOS 应用脚本

配套文件：`fnos-depenv.py`（放到应用根目录，与 `gateway-proxy.py`、`hermes-update.py` 同级，
即安装后为 `${TRIM_APPDEST}/fnos-depenv.py`）。

两处调用点：**服务启动时**（必须）和**安装/升级后**（建议）。脚本幂等、耗时约 0.3s。

---

## 1. `cmd/main`

### 1.1 新增函数（放在 `start_process()` 之前，紧邻 `start_gateway_supervisor()` 之后）

```bash
### 依赖环境登记（缺陷：子进程 exit 1 "no dependency environment is committed"）。
###
### 为什么要这一步：本包自带 CPython，依赖预装在其 site-packages，不走 PM 的 uv 构建。
### 但 PM 自己的 store Python 存在于 ${DATA_DIR}/tools/，而上游
### hermes_cli/_launchers.py::runtime_command() 会优先用 store Python 拉起子进程；
### 子进程启动时 pm/environments.py::activate_dependencies() 找不到任何「已提交的
### 依赖环境」，于是 _require_own_dependencies() 对「非 venv + base_prefix 在 store 内」
### 的解释器直接拒绝 → exit 1。凡走 runtime_command 的子进程全灭：
### dashboard 的 doctor / 安全审计 / 备份 / 导入 / curator / prompt-size / dump、
### 「重启网关」、cron 的 .py 脚本等。
###
### 这里在 install state 里登记一个指向自带 CPython 的依赖环境（等价于 PM 本来会做
### 的那一步），committed_venv() 不再返回 None，拒绝分支永不被触达。
### 只写 ${DATA_DIR}/installs/<key>/，不改应用包；PM 工具链（uv/chromium/
### agent-browser/tirith）行为完全不变。
###
### 必须在服务启动时跑：解释器版本升级（3.14→3.15）或应用换卷后路径变化，
### 登记都需要跟着重建。
ensure_dependency_environment() {
    local helper="${APP_DIR}/fnos-depenv.py"
    if [ ! -f "${helper}" ]; then
        log_msg "警告：缺少 ${helper}，dashboard 子动作会报 'no dependency environment is committed'"
        return 0
    fi
    ### 只允许用应用自己的解释器：用 PM store Python 跑会把登记指向裸解释器，
    ### 子进程虽不再报 pm repair，却会在第一个 import 上崩掉（脚本内也有同样的拒绝）。
    if [ "$(id -un)" = "${TRIM_USERNAME}" ]; then
        env HOME="${DATA_DIR}" HERMES_HOME="${DATA_DIR}" HERMES_PKG_SRC="${SRC_DIR}" \
            "${PY}" "${helper}" >> "${LOG_FILE}" 2>&1
    else
        runuser -u "${TRIM_USERNAME}" -- env HOME="${DATA_DIR}" HERMES_HOME="${DATA_DIR}" \
            HERMES_PKG_SRC="${SRC_DIR}" "${PY}" "${helper}" >> "${LOG_FILE}" 2>&1
    fi
    ### 失败不阻断启动：登记缺失只会让子动作退回旧症状，服务本身照常可用。
    return 0
}
```

### 1.2 在 `start_process()` 里调用

插入位置：`WEB_DIST/index.html` 完整性检查之后、`local ws` 之前。

```bash
    if [ ! -f "${WEB_DIST}/index.html" ]; then
        log_msg "启动失败：缺少预构建前端（web_dist）"
        echo "应用缺少预构建前端（web_dist）" > "${TRIM_TEMP_LOGFILE}"
        return 1
    fi

+   ### 依赖环境登记：必须在拉起 dashboard 之前完成，否则它 spawn 的第一个
+   ### 子动作就会撞上 "no dependency environment is committed"。
+   ensure_dependency_environment

    local ws
    ws="$(resolve_workspace)"
```

---

## 2. `cmd/install_callback`

插入位置：文件末尾 `chown -R ...` 之后、`exit 0` 之前（必须在 chown 之后，
否则 runuser 成 ${TRIM_USERNAME} 的写入会被权限挡住）。

```bash
chown -R "${TRIM_USERNAME}:${TRIM_GROUPNAME}" "${TRIM_PKGVAR}" 2>/dev/null || true

+# 依赖环境登记（见 runtime/fnos-depenv.py 的说明）。
+# 打包模式：解释器是 ${PY}；系统 Python 模式：用 ${TRIM_PKGVAR}/venv/bin/python3。
+DEPENV_PY="${PY}"
+[ -x "${DEPENV_PY}" ] || DEPENV_PY="${TRIM_PKGVAR}/venv/bin/python3"
+if [ -f "${TRIM_APPDEST}/fnos-depenv.py" ] && [ -x "${DEPENV_PY}" ]; then
+    runuser -u "${TRIM_USERNAME}" -- env HOME="${TRIM_PKGVAR}" HERMES_HOME="${TRIM_PKGVAR}" \
+        HERMES_PKG_SRC="${RUNTIME}/hermes" "${DEPENV_PY}" "${TRIM_APPDEST}/fnos-depenv.py" \
+        >> "${TRIM_PKGVAR}/info.log" 2>&1 || true
+fi
+
exit 0
```

---

## 3. 打包时顺带确认（非必需，但建议）

1. **`fnos-depenv.py` 的权限**：fnpack 会把权限拍平成 0666。脚本是用
   `"${PY}" "${helper}"` 调用的，不依赖执行位，所以无需 `chmod +x`。
2. **不要往包里塞 `$HERMES_HOME/tools`**：PM 的 store（含 store Python）属于数据目录，
   由运行时按需下载；包内不要预置，也不要删——删了下次 `pm.ensure` 会重新下载。
3. **`.git` 不要随包分发**：当前包内的源码树带着 `.git`（`git status` 显示 16899 个
   改动），会让 `hermes update --plan` 把安装类型误报成 `git`，也显著增大包体。
   上游的 sealed payload 用 `git archive` 导出（`scripts/bundles/payload.py::snapshot`），
   不含 `.git`。建议打包时同样排除。
4. **验证方法**（装完即可自查，任何一条不再出现 `no dependency environment is
   committed` 即为通过）：

   ```bash
   STORE_PY=$(ls -d "$TRIM_PKGVAR"/tools/python-*/ | head -1)bin/python3
   "$STORE_PY" -I -c "import os,sys,runpy; os.environ.pop('PYTHONPATH',None); \
     sys.path.insert(0,'/vol1/@appcenter/hermes/runtime/hermes'); \
     os.environ['HERMES_HOME']='/vol1/@appdata/hermes'; \
     import hermes_bootstrap; runpy.run_module('hermes_cli.main',run_name='__main__',alter_sys=True)" doctor
   ```
